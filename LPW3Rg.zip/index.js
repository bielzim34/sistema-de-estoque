const express = require ('express')
const app = express();
app.set("view engine","ejs");
app.use(express.urlencoded({extended:true}));
app.use(express.static('public'));

const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://eglms_db_user:1c4qKdl0NpE4VQsU@cluster0.yobunds.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

const Fornecedor = require("./models/Fornecedor");
const Produto = require("./models/produto");

app.get("/", function(req, res){
    
    res.render("index")
});


app.post("/fornecedores", async function(req, res){

    const fornecedor= req.body;

    const novoFornecedor = new Fornecedor({

        nome:fornecedor.nome,
        endereço:fornecedor.endereço,
        codf: fornecedor.codf
        });
        await novoFornecedor.save();
    res.redirect("/fornecedores?s=1");
    
});

app.get("/fornecedores", async function(req, res){
    const status = req.query.s;
    const fornecedores = await Fornecedor.find();
    res.render("fornecedor/relatorio",{fornecedores, status});
    
});

app.get("/fornecedores/cadastrar", function(req, res){
    res.render("fornecedor/cadastrar");
    
});

app.get("/fornecedores/:nome", async function(req, res){
    const fornecedor = await Fornecedor.findOne({nome: req.params.nome})
    res.render("fornecedor/detalhar", {fornecedor});
});

app.post("/produtos", async function(req, res){

    const produto= req.body;

    const novoProduto = new Produto({

        nome:produto.nome,
        marca:produto.marca,
        qproduto:produto.qproduto,
        codp: produto.codp
        });
        await novoProduto.save();
    res.redirect("/produtos?s=1");
    
});

app.get("/produtos", async function(req, res){
    const status = req.query.s;
    const produtos = await Produto.find();
    res.render("produto/relatorio",{produtos, status});
    
});

app.get("/produtos/cadastrar", function(req, res){
    res.render("produto/cadastrar");
    
});

app.get("/produtos/:nome", async function(req, res){
    const produto = await Produto.findOne({nome: req.params.nome})
    res.render("produto/detalhar", {produto});
});





    app.use(function(req, res){
        res.status(404).render("404");
    });

app.listen("999", function(){
    console.log("Rodando...");
});